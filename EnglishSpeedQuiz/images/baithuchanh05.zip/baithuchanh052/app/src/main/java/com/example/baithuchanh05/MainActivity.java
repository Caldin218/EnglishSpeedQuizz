package com.example.baithuchanh05;

import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.GridView; // Đã thêm import này
import android.widget.ListView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    ListView listView;
    GridView gridView;

    // Dữ liệu mẫu cho ListView [cite: 14-24]
    String[] names = {"Nguyễn An", "Trần Bình", "Lê Cường", "Phạm Dũng",
            "Hoàng Giang", "Võ Khánh", "Đặng Minh", "Bùi Nam",
            "Đỗ Quang", "Trịnh Sơn"};

    // Dữ liệu mẫu cho GridView (Đảm bảo bạn đã có hình trong res/drawable) [cite: 33]
    int[] myImages = {
            R.drawable.hinh1, R.drawable.hinh2, R.drawable.hinh3,
            R.drawable.hinh4, R.drawable.hinh5, R.drawable.hinh6
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // --- XỬ LÝ LISTVIEW ---
        listView = findViewById(R.id.listViewNames);
        ArrayAdapter<String> listAdapter = new ArrayAdapter<>(
                this,
                android.R.layout.simple_list_item_1,
                names
        );
        listView.setAdapter(listAdapter); // [cite: 28]

        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                String tenDaChon = names[position];
                // Hiển thị Toast: Xin chào [Tên] [cite: 29]
                Toast.makeText(MainActivity.this, "Xin chào " + tenDaChon, Toast.LENGTH_SHORT).show();
            }
        });

        // --- XỬ LÝ GRIDVIEW ---
        gridView = findViewById(R.id.gridViewImages);
        // Lưu ý: Phải có class ImageAdapter (xem bên dưới)
        ImageAdapter imageAdapter = new ImageAdapter(this, myImages);
        gridView.setAdapter(imageAdapter); // [cite: 36]

        gridView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                // Hiển thị Toast: Bạn đã chọn ảnh thứ... [cite: 34]
                Toast.makeText(MainActivity.this, "Bạn đã chọn ảnh thứ " + (position + 1), Toast.LENGTH_SHORT).show();
            }
        });
    }
}