package com.example.baithuchanh05;

import android.content.Context;
import android.graphics.Color;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

public class ColorAdapter extends BaseAdapter {
    private Context context;
    private String[] nameList;
    private String[] colorHexList;

    public ColorAdapter(Context context, String[] nameList, String[] colorHexList) {
        this.context = context;
        this.nameList = nameList;
        this.colorHexList = colorHexList;
    }

    @Override
    public int getCount() { return nameList.length; }

    @Override
    public Object getItem(int position) { return null; }

    @Override
    public long getItemId(int position) { return 0; }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        if (convertView == null) {
            LayoutInflater inflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            // Layout cho từng ô màu
            convertView = inflater.inflate(R.layout.item_color, null);
        }

        TextView tvColor = convertView.findViewById(R.id.tvColorItem);
        tvColor.setText(nameList[position]);
        // Chuyển mã Hex string thành màu thực tế
        tvColor.setBackgroundColor(Color.parseColor(colorHexList[position]));

        return convertView;
    }
}