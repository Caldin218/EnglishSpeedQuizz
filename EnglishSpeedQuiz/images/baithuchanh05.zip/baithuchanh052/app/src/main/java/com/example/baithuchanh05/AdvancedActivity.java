package com.example.baithuchanh05;

import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.GridView;
import android.widget.ListView;
import androidx.appcompat.app.AppCompatActivity;

public class AdvancedActivity extends AppCompatActivity {

    String[] colorNames = {"Red", "Orange", "Yellow", "Green", "Blue", "Purple"};
    String[] colorHexs = {"#FF0000", "#FFA500", "#FFD700", "#008000", "#0000FF", "#800080"};

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_advanced); // Trỏ tới file giao diện mới

        // Xử lý ListView
        ListView listView = findViewById(R.id.listViewColors);
        ArrayAdapter<String> adapterList = new ArrayAdapter<>(
                this,
                android.R.layout.simple_list_item_1,
                colorNames
        );
        listView.setAdapter(adapterList);

        // Xử lý GridView
        GridView gridView = findViewById(R.id.gridViewColors);
        // Nhớ là phải có file ColorAdapter.java và item_color.xml đã tạo ở bước trước nhé
        ColorAdapter adapterGrid = new ColorAdapter(this, colorNames, colorHexs);
        gridView.setAdapter(adapterGrid);
    }
}